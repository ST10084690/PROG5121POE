/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testTaskDescriptionSuccess() {
        Task task = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertTrue(task.checkTaskDescription());
    }

    @Test
    public void testTaskDescriptionFailure() {
        Task task = new Task("Login Feature", 0, "This description is definitely more than fifty characters long and should fail", "Robyn Harrison", 8, "To Do");
        assertFalse(task.checkTaskDescription());
    }

    @Test
    public void testTaskIDCreation() {
        Task task = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertEquals("LO:0:SON", task.createTaskID());
    }

    @Test
    public void testTotalHours() {
        TaskManager taskManager = new TaskManager("Test", "User");
        taskManager.tasks.add(new Task("Task1", 0, "Description1", "Dev One", 10, "To Do"));
        taskManager.tasks.add(new Task("Task2", 1, "Description2", "Dev Two", 12, "Doing"));
        taskManager.tasks.add(new Task("Task3", 2, "Description3", "Dev Three", 55, "Done"));
        taskManager.tasks.add(new Task("Task4", 3, "Description4", "Dev Four", 11, "To Do"));
        taskManager.tasks.add(new Task("Task5", 4, "Description5", "Dev Five", 1, "Doing"));
        int totalHours = taskManager.tasks.stream().mapToInt(Task::getTaskDuration).sum();
        assertEquals(89, totalHours);
    }
}
