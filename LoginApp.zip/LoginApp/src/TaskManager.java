/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class TaskManager {
    private String firstName;
    private String lastName;
    public ArrayList<Task> tasks;

    public TaskManager(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.tasks = new ArrayList<>();
    }

    public void run() {
        while (true) {
            String option = JOptionPane.showInputDialog(null,
                    "Welcome to EasyKanban\n\n1. Add tasks\n2. Show report\n3. Quit\n\nEnter option number:");
            int choice = Integer.parseInt(option);

            if (choice == 1) {
                int numTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "How many tasks do you want to add?"));
                for (int i = 0; i < numTasks; i++) {
                    String taskName = JOptionPane.showInputDialog(null, "Enter task name:");
                    String taskDescription = JOptionPane.showInputDialog(null, "Enter task description:");
                    String developerDetails = JOptionPane.showInputDialog(null, "Enter developer details:");
                    int taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter task duration (in hours):"));
                    String[] statuses = {"To Do", "Done", "Doing"};
                    String taskStatus = (String) JOptionPane.showInputDialog(null, "Select task status:", "Task Status",
                            JOptionPane.QUESTION_MESSAGE, null, statuses, statuses[0]);

                    Task task = new Task(taskName, tasks.size(), taskDescription, developerDetails, taskDuration, taskStatus);
                    if (task.checkTaskDescription()) {
                        tasks.add(task);
                        JOptionPane.showMessageDialog(null, "Task successfully captured\n" + task.printTaskDetails());
                    } else {
                        JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                    }
                }
            } else if (choice == 2) {
                JOptionPane.showMessageDialog(null, "Coming Soon");
            } else if (choice == 3) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid option number.");
            }
        }

        int totalHours = tasks.stream().mapToInt(Task::getTaskDuration).sum();
        JOptionPane.showMessageDialog(null, "Total number of hours across all tasks: " + totalHours);
    }
}

