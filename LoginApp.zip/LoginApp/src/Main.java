/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        Login login = new Login();

        while (true) {
            String option = JOptionPane.showInputDialog(null, "Welcome to EasyKanban\n\n1. Register\n2. Login\n\nEnter option number:");
            int choice = Integer.parseInt(option);

            if (choice == 1) {
                String username = JOptionPane.showInputDialog(null, "Enter username:");
                String password = JOptionPane.showInputDialog(null, "Enter password:");
                String firstName = JOptionPane.showInputDialog(null, "Enter first name:");
                String lastName = JOptionPane.showInputDialog(null, "Enter last name:");

                login.setFirstName(firstName);
                login.setLastName(lastName);

                String registrationMessage = login.registerUser(username, password);
                JOptionPane.showMessageDialog(null, registrationMessage);
            } else if (choice == 2) {
                String enteredUsername = JOptionPane.showInputDialog(null, "Enter username:");
                String enteredPassword = JOptionPane.showInputDialog(null, "Enter password:");

                boolean isAuthenticated = login.loginUser(enteredUsername, enteredPassword);
                String loginStatus = login.returnLoginStatus(isAuthenticated);
                JOptionPane.showMessageDialog(null, loginStatus);

                if (isAuthenticated) {
                    TaskManager taskManager = new TaskManager(login.getFirstName(), login.getLastName());
                    taskManager.run();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid option number.");
            }
        }
    }
}
